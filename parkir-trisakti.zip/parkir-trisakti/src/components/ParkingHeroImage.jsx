import React from 'react';

export default function ParkingHeroImage() {
  return (
    <div className="position-relative text-center">
      {/* Soft Glow Ambient Backdrop */}
      <div 
        className="position-absolute top-50 start-50 translate-middle rounded-circle"
        style={{
          width: '320px',
          height: '320px',
          background: 'radial-gradient(circle, rgba(245, 166, 35, 0.2) 0%, rgba(10, 48, 104, 0) 70%)',
          filter: 'blur(35px)',
          zIndex: 0
        }}
      ></div>

      {/* Modern Parking Illustration Card */}
      <div 
        className="card border-0 shadow-lg position-relative overflow-hidden mx-auto"
        style={{
          borderRadius: '24px',
          background: '#ffffff',
          border: '3px solid rgba(255, 255, 255, 0.9)',
          maxWidth: '540px',
          zIndex: 1
        }}
      >
        {/* SVG Ilustrasi Area Parkir Modern */}
        <svg 
          viewBox="0 0 600 420" 
          className="w-100 h-auto d-block" 
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Background Sky & Campus Silhouette */}
          <rect width="600" height="420" fill="#f1f5f9" />
          
          {/* Sky Gradient Header */}
          <linearGradient id="skyGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#0a3068" />
            <stop offset="100%" stopColor="#1e3a8a" />
          </linearGradient>
          <rect width="600" height="150" fill="url(#skyGrad)" />

          {/* Sun / Light glow */}
          <circle cx="500" cy="50" r="35" fill="#f5a623" opacity="0.3" />
          <circle cx="500" cy="50" r="22" fill="#fde047" opacity="0.8" />

          {/* Campus Buildings Silhouette */}
          {/* Building 1 (Gedung M Trisakti) */}
          <rect x="50" y="55" width="110" height="95" rx="3" fill="#1e293b" opacity="0.95" />
          {/* Windows */}
          <rect x="62" y="68" width="16" height="14" rx="2" fill="#93c5fd" opacity="0.8" />
          <rect x="86" y="68" width="16" height="14" rx="2" fill="#93c5fd" opacity="0.8" />
          <rect x="110" y="68" width="16" height="14" rx="2" fill="#fef08a" opacity="0.9" />
          <rect x="134" y="68" width="16" height="14" rx="2" fill="#93c5fd" opacity="0.8" />
          <rect x="62" y="92" width="16" height="14" rx="2" fill="#93c5fd" opacity="0.8" />
          <rect x="86" y="92" width="16" height="14" rx="2" fill="#fef08a" opacity="0.9" />
          <rect x="110" y="92" width="16" height="14" rx="2" fill="#93c5fd" opacity="0.8" />
          <rect x="134" y="92" width="16" height="14" rx="2" fill="#93c5fd" opacity="0.8" />
          <rect x="62" y="116" width="16" height="14" rx="2" fill="#93c5fd" opacity="0.8" />
          <rect x="86" y="116" width="16" height="14" rx="2" fill="#93c5fd" opacity="0.8" />
          <rect x="110" y="116" width="16" height="14" rx="2" fill="#93c5fd" opacity="0.8" />
          <rect x="134" y="116" width="16" height="14" rx="2" fill="#93c5fd" opacity="0.8" />

          {/* Building 2 (Tower Kampus) */}
          <rect x="175" y="30" width="140" height="120" rx="4" fill="#0f172a" />
          <rect x="190" y="45" width="22" height="15" rx="2" fill="#38bdf8" opacity="0.75" />
          <rect x="220" y="45" width="22" height="15" rx="2" fill="#38bdf8" opacity="0.75" />
          <rect x="250" y="45" width="22" height="15" rx="2" fill="#fef08a" opacity="0.85" />
          <rect x="280" y="45" width="22" height="15" rx="2" fill="#38bdf8" opacity="0.75" />
          <rect x="190" y="70" width="22" height="15" rx="2" fill="#38bdf8" opacity="0.75" />
          <rect x="220" y="70" width="22" height="15" rx="2" fill="#fef08a" opacity="0.85" />
          <rect x="250" y="70" width="22" height="15" rx="2" fill="#38bdf8" opacity="0.75" />
          <rect x="280" y="70" width="22" height="15" rx="2" fill="#38bdf8" opacity="0.75" />
          <rect x="190" y="95" width="22" height="15" rx="2" fill="#38bdf8" opacity="0.75" />
          <rect x="220" y="95" width="22" height="15" rx="2" fill="#38bdf8" opacity="0.75" />
          <rect x="250" y="95" width="22" height="15" rx="2" fill="#38bdf8" opacity="0.75" />
          <rect x="280" y="95" width="22" height="15" rx="2" fill="#38bdf8" opacity="0.75" />
          {/* Trisakti Logo Badge on Building */}
          <rect x="225" y="35" width="40" height="6" rx="2" fill="#f5a623" />

          {/* Building 3 (Gedung Fakultas) */}
          <rect x="330" y="65" width="130" height="85" rx="3" fill="#1e293b" opacity="0.9" />
          <rect x="345" y="80" width="20" height="15" rx="2" fill="#93c5fd" opacity="0.8" />
          <rect x="375" y="80" width="20" height="15" rx="2" fill="#93c5fd" opacity="0.8" />
          <rect x="405" y="80" width="20" height="15" rx="2" fill="#93c5fd" opacity="0.8" />
          <rect x="435" y="80" width="15" height="15" rx="2" fill="#93c5fd" opacity="0.8" />
          <rect x="345" y="105" width="20" height="15" rx="2" fill="#fef08a" opacity="0.9" />
          <rect x="375" y="105" width="20" height="15" rx="2" fill="#93c5fd" opacity="0.8" />
          <rect x="405" y="105" width="20" height="15" rx="2" fill="#93c5fd" opacity="0.8" />

          {/* Green Trees along perimeter */}
          <circle cx="35" cy="145" r="22" fill="#15803d" />
          <circle cx="475" cy="148" r="20" fill="#16a34a" />
          <circle cx="510" cy="145" r="26" fill="#15803d" />
          <circle cx="545" cy="148" r="22" fill="#166534" />

          {/* Ground / Asphalt Parking Area */}
          <rect x="0" y="150" width="600" height="270" fill="#334155" />

          {/* Parking Road Marking Texture */}
          <line x1="0" y1="280" x2="600" y2="280" stroke="#f8fafc" strokeWidth="4" strokeDasharray="14 14" opacity="0.6" />

          {/* ================= PARKING BAYS (SLOTS) ================= */}
          {/* Row 1: Top Parking Slots (Perpendicular) */}
          {/* Slot 1 */}
          <rect x="30" y="165" width="75" height="100" rx="3" fill="#1e293b" stroke="#ffffff" strokeWidth="3" strokeDasharray="0 181 75 0" />
          {/* Blue Car parked in Slot 1 */}
          <g transform="translate(42, 175)">
            <rect x="0" y="0" width="50" height="80" rx="10" fill="#2563eb" />
            <rect x="4" y="15" width="42" height="48" rx="6" fill="#1e3a8a" />
            <rect x="8" y="24" width="34" height="28" rx="4" fill="#93c5fd" />
            {/* Mirrors */}
            <rect x="-4" y="24" width="5" height="8" rx="2" fill="#1d4ed8" />
            <rect x="49" y="24" width="5" height="8" rx="2" fill="#1d4ed8" />
            {/* Lights */}
            <circle cx="10" cy="5" r="3" fill="#fef08a" />
            <circle cx="40" cy="5" r="3" fill="#fef08a" />
            <circle cx="10" cy="75" r="3" fill="#ef4444" />
            <circle cx="40" cy="75" r="3" fill="#ef4444" />
          </g>

          {/* Slot 2 */}
          <rect x="115" y="165" width="75" height="100" rx="3" fill="#1e293b" stroke="#ffffff" strokeWidth="3" />
          {/* White / Silver SUV parked in Slot 2 */}
          <g transform="translate(127, 175)">
            <rect x="0" y="0" width="50" height="80" rx="10" fill="#f1f5f9" />
            <rect x="4" y="14" width="42" height="50" rx="6" fill="#cbd5e1" />
            <rect x="8" y="22" width="34" height="32" rx="4" fill="#64748b" />
            <rect x="-4" y="24" width="5" height="8" rx="2" fill="#94a3b8" />
            <rect x="49" y="24" width="5" height="8" rx="2" fill="#94a3b8" />
            <circle cx="10" cy="5" r="3" fill="#fef08a" />
            <circle cx="40" cy="5" r="3" fill="#fef08a" />
            <circle cx="10" cy="75" r="3" fill="#ef4444" />
            <circle cx="40" cy="75" r="3" fill="#ef4444" />
          </g>

          {/* Slot 3: Empty Slot with "P" Marking */}
          <rect x="200" y="165" width="75" height="100" rx="3" fill="#1e293b" stroke="#ffffff" strokeWidth="3" />
          <circle cx="237" cy="215" r="22" fill="#0284c7" opacity="0.8" />
          <text x="230" y="224" fill="#ffffff" fontSize="24" fontWeight="bold" fontFamily="sans-serif">P</text>

          {/* Slot 4 */}
          <rect x="285" y="165" width="75" height="100" rx="3" fill="#1e293b" stroke="#ffffff" strokeWidth="3" />
          {/* Red Car in Slot 4 */}
          <g transform="translate(297, 175)">
            <rect x="0" y="0" width="50" height="80" rx="10" fill="#dc2626" />
            <rect x="4" y="15" width="42" height="48" rx="6" fill="#991b1b" />
            <rect x="8" y="24" width="34" height="28" rx="4" fill="#fca5a5" />
            <rect x="-4" y="24" width="5" height="8" rx="2" fill="#b91c1c" />
            <rect x="49" y="24" width="5" height="8" rx="2" fill="#b91c1c" />
            <circle cx="10" cy="5" r="3" fill="#fef08a" />
            <circle cx="40" cy="5" r="3" fill="#fef08a" />
            <circle cx="10" cy="75" r="3" fill="#f87171" />
            <circle cx="40" cy="75" r="3" fill="#f87171" />
          </g>

          {/* Slot 5 (Motorcycle Zone) */}
          <rect x="370" y="165" width="85" height="100" rx="3" fill="#1e293b" stroke="#f5a623" strokeWidth="3" />
          {/* Motorcycles */}
          <g transform="translate(380, 185)">
            {/* Motor 1 */}
            <rect x="0" y="0" width="16" height="55" rx="4" fill="#0f172a" />
            <circle cx="8" cy="10" r="5" fill="#3b82f6" />
            <circle cx="8" cy="5" r="3" fill="#fef08a" />
            {/* Motor 2 */}
            <rect x="26" y="5" width="16" height="55" rx="4" fill="#0f172a" />
            <circle cx="34" cy="15" r="5" fill="#eab308" />
            <circle cx="34" cy="10" r="3" fill="#fef08a" />
            {/* Motor 3 */}
            <rect x="52" y="0" width="16" height="55" rx="4" fill="#0f172a" />
            <circle cx="60" cy="10" r="5" fill="#22c55e" />
            <circle cx="60" cy="5" r="3" fill="#fef08a" />
          </g>
          <text x="382" y="258" fill="#f5a623" fontSize="10" fontWeight="bold" fontFamily="sans-serif">MOTOR TRISAKTI</text>

          {/* Entrance Booth & Gate Post */}
          <g transform="translate(485, 175)">
            {/* Guard Booth */}
            <rect x="0" y="0" width="85" height="70" rx="6" fill="#0a3068" stroke="#f5a623" strokeWidth="2" />
            <rect x="10" y="12" width="65" height="30" rx="3" fill="#93c5fd" opacity="0.85" />
            <rect x="25" y="48" width="35" height="22" fill="#07224c" />
            <text x="14" y="60" fill="#ffffff" fontSize="8" fontWeight="bold" fontFamily="sans-serif">POS GATE</text>
            
            {/* Barrier Gate Arm */}
            <rect x="-35" y="40" width="35" height="6" rx="2" fill="#ffffff" stroke="#dc2626" strokeWidth="1.5" />
            <circle cx="0" cy="43" r="6" fill="#10b981" />
          </g>

          {/* Row 2: Bottom Parking Slots / Car in driving lane */}
          {/* Moving car in transit */}
          <g transform="translate(180, 310)">
            <rect x="0" y="0" width="115" height="58" rx="10" fill="#f5a623" />
            <rect x="22" y="6" width="60" height="46" rx="6" fill="#b45309" />
            <rect x="30" y="10" width="44" height="38" rx="4" fill="#fef08a" opacity="0.9" />
            <circle cx="108" cy="15" r="4" fill="#ffffff" />
            <circle cx="108" cy="43" r="4" fill="#ffffff" />
            <circle cx="6" cy="15" r="4" fill="#ef4444" />
            <circle cx="6" cy="43" r="4" fill="#ef4444" />
            <text x="35" y="34" fill="#000000" fontSize="11" fontWeight="bold" fontFamily="monospace">TRISAKTI</text>
          </g>

          {/* Clean Overlay Banner at bottom */}
          <rect x="0" y="375" width="600" height="45" fill="#07224c" />
          <text x="25" y="402" fill="#ffffff" fontSize="13" fontWeight="bold" fontFamily="sans-serif">
            AREA PARKIR KAMPUS A - UNIVERSITAS TRISAKTI
          </text>
          <text x="450" y="402" fill="#f5a623" fontSize="12" fontWeight="bold" fontFamily="sans-serif">
            JAKARTA BARAT
          </text>
        </svg>

        {/* Caption Banner underneath image */}
        <div className="card-body py-2 px-3 bg-light text-center border-top">
          <small className="text-muted fw-semibold d-flex align-items-center justify-content-center gap-2">
            <i className="bi bi-geo-alt-fill text-danger"></i>
            <span>Area Parkir Terpadu Gedung M, Gedung H & L, dan Kampus A Universitas Trisakti</span>
          </small>
        </div>
      </div>
    </div>
  );
}
