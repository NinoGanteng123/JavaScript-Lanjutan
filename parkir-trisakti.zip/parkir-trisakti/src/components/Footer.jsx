import React from 'react';
import { Link } from 'react-router-dom';

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToFeatures = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setTimeout(() => {
      document.getElementById('fitur-utama')?.scrollIntoView({ behavior: 'smooth' });
    }, 150);
  };

  return (
    <footer className="footer-trisakti mt-auto pt-5 pb-4">
      <div className="container">
        <div className="row g-4 mb-4">
          {/* Column 1: Info Kampus */}
          <div className="col-lg-4 col-md-6">
            <div className="d-flex align-items-center gap-2 mb-3">
              <div 
                className="rounded-3 d-flex align-items-center justify-content-center bg-white text-primary"
                style={{ width: '38px', height: '38px', border: '2px solid var(--usakti-gold)' }}
              >
                <i className="bi bi-p-square-fill fs-5" style={{ color: 'var(--usakti-primary)' }}></i>
              </div>
              <h5 className="text-white mb-0 brand-font">
                Sistem Parkir <span style={{ color: 'var(--usakti-gold)' }}>Trisakti</span>
              </h5>
            </div>
            <p className="text-secondary small mb-3">
              Sistem Pengelolaan dan Monitoring Parkir Terpadu Kampus A &amp; B Universitas Trisakti.
              Mendukung transformasi digital smart campus untuk civitas akademika Trisakti yang aman, nyaman, dan transparan.
            </p>
            <div className="d-flex flex-wrap gap-2">
              <span className="badge bg-primary bg-opacity-25 text-info border border-info border-opacity-25 px-2 py-1">
                <i className="bi bi-shield-check me-1"></i> RFID &amp; LPR Integrated
              </span>
              <span className="badge bg-warning bg-opacity-10 text-warning border border-warning border-opacity-25 px-2 py-1">
                <i className="bi bi-geo-alt me-1"></i> Kampus A Grogol
              </span>
            </div>
          </div>

          {/* Column 2: Navigasi Cepat (React Router Link) */}
          <div className="col-lg-2 col-md-6">
            <h6 className="text-white fw-bold mb-3 text-uppercase" style={{ letterSpacing: '0.5px', fontSize: '0.9rem' }}>
              Menu Utama
            </h6>
            <ul className="list-unstyled d-flex flex-column gap-2 small">
              <li>
                <Link 
                  to="/" 
                  className="text-secondary text-decoration-none d-inline-flex align-items-center"
                  onClick={scrollToTop}
                >
                  <i className="bi bi-chevron-right me-1 text-warning"></i> Halaman Home
                </Link>
              </li>
              <li>
                <Link 
                  to="/team" 
                  className="text-secondary text-decoration-none d-inline-flex align-items-center"
                  onClick={scrollToTop}
                >
                  <i className="bi bi-chevron-right me-1 text-warning"></i> Profil Tim Pengembang
                </Link>
              </li>
              <li>
                <Link 
                  to="/contact" 
                  className="text-secondary text-decoration-none d-inline-flex align-items-center"
                  onClick={scrollToTop}
                >
                  <i className="bi bi-chevron-right me-1 text-warning"></i> Kontak &amp; Lokasi Kampus
                </Link>
              </li>
              <li>
                <Link 
                  to="/" 
                  className="text-secondary text-decoration-none d-inline-flex align-items-center"
                  onClick={scrollToFeatures}
                >
                  <i className="bi bi-chevron-right me-1 text-warning"></i> 3 Fitur Unggulan
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 3: Tautan Terkait Trisakti */}
          <div className="col-lg-3 col-md-6">
            <h6 className="text-white fw-bold mb-3 text-uppercase" style={{ letterSpacing: '0.5px', fontSize: '0.9rem' }}>
              Portal Trisakti
            </h6>
            <ul className="list-unstyled d-flex flex-column gap-2 small">
              <li>
                <a href="https://www.trisakti.ac.id" target="_blank" rel="noreferrer" className="text-secondary text-decoration-none">
                  <i className="bi bi-box-arrow-up-right me-1 text-warning"></i> Website Resmi Trisakti
                </a>
              </li>
              <li>
                <a href="https://fti.trisakti.ac.id" target="_blank" rel="noreferrer" className="text-secondary text-decoration-none">
                  <i className="bi bi-box-arrow-up-right me-1 text-warning"></i> Fakultas Teknologi Industri (FTI)
                </a>
              </li>
              <li>
                <a href="https://informatika.trisakti.ac.id" target="_blank" rel="noreferrer" className="text-secondary text-decoration-none">
                  <i className="bi bi-box-arrow-up-right me-1 text-warning"></i> Jurusan Informatika Trisakti
                </a>
              </li>
              <li>
                <a href="https://siakad.trisakti.ac.id" target="_blank" rel="noreferrer" className="text-secondary text-decoration-none">
                  <i className="bi bi-box-arrow-up-right me-1 text-warning"></i> Portal SIAKAD Civitas
                </a>
              </li>
            </ul>
          </div>

          {/* Column 4: Kontak Singkat */}
          <div className="col-lg-3 col-md-6">
            <h6 className="text-white fw-bold mb-3 text-uppercase" style={{ letterSpacing: '0.5px', fontSize: '0.9rem' }}>
              Helpdesk Parkir
            </h6>
            <p className="text-secondary small mb-2">
              <i className="bi bi-geo-alt-fill text-warning me-2"></i>
              Gedung M Lantai 1, Kampus A Universitas Trisakti, Grogol, Jakarta Barat.
            </p>
            <p className="text-secondary small mb-2">
              <i className="bi bi-telephone-fill text-warning me-2"></i>
              (021) 5663232 Ext. 8114
            </p>
            <p className="text-secondary small mb-3">
              <i className="bi bi-envelope-fill text-warning me-2"></i>
              parkir@trisakti.ac.id
            </p>
            <div className="d-flex gap-2">
              <a href="https://facebook.com" target="_blank" rel="noreferrer" className="btn btn-sm btn-outline-secondary rounded-circle" style={{ width: '34px', height: '34px', padding: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <i className="bi bi-facebook"></i>
              </a>
              <a href="https://instagram.com" target="_blank" rel="noreferrer" className="btn btn-sm btn-outline-secondary rounded-circle" style={{ width: '34px', height: '34px', padding: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <i className="bi bi-instagram"></i>
              </a>
              <a href="https://twitter.com" target="_blank" rel="noreferrer" className="btn btn-sm btn-outline-secondary rounded-circle" style={{ width: '34px', height: '34px', padding: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <i className="bi bi-twitter-x"></i>
              </a>
              <a href="https://youtube.com" target="_blank" rel="noreferrer" className="btn btn-sm btn-outline-secondary rounded-circle" style={{ width: '34px', height: '34px', padding: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <i className="bi bi-youtube"></i>
              </a>
            </div>
          </div>
        </div>

        <hr className="border-secondary opacity-25 my-4" />

        <div className="row align-items-center">
          <div className="col-md-7 text-center text-md-start mb-2 mb-md-0">
            <small className="text-secondary">
              &copy; {new Date().getFullYear()} <strong>Universitas Trisakti</strong> - Dikembangkan oleh Mahasiswa Informatika FTI Trisakti.
            </small>
          </div>
          <div className="col-md-5 text-center text-md-end">
            <span className="badge bg-warning text-dark fw-semibold px-2 py-1">
              Versi 2.4.0-Production
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
