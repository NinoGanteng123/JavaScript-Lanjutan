import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import './Navbar.css';

export default function Navbar() {
  const [isNavCollapsed, setIsNavCollapsed] = useState(true);

  const handleNavCollapse = () => setIsNavCollapsed(!isNavCollapsed);
  const closeNav = () => {
    setIsNavCollapsed(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark navbar-custom-trisakti sticky-top">
      <div className="container">
        {/* Brand Logo & Name */}
        <Link 
          to="/" 
          className="navbar-brand d-flex align-items-center gap-2"
          onClick={closeNav}
        >
          <div className="brand-icon-box">
            <i className="bi bi-p-square-fill"></i>
          </div>
          <div>
            <span className="brand-title">
              PARKIR <span className="brand-gold">TRISAKTI</span>
            </span>
            <small className="brand-subtitle">
              UNIVERSITAS TRISAKTI JAKARTA
            </small>
          </div>
        </Link>

        {/* Mobile Toggler */}
        <button
          className={`navbar-toggler custom-toggler ${isNavCollapsed ? 'collapsed' : ''}`}
          type="button"
          onClick={handleNavCollapse}
          aria-controls="navbarTrisaktiContent"
          aria-expanded={!isNavCollapsed}
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon-custom">
            <i className={`bi ${isNavCollapsed ? 'bi-list' : 'bi-x-lg'} fs-3`}></i>
          </span>
        </button>

        {/* Nav Links */}
        <div className={`collapse navbar-collapse ${!isNavCollapsed ? 'show' : ''}`} id="navbarTrisaktiContent">
          <ul className="navbar-nav ms-auto mb-2 mb-lg-0 align-items-lg-center">
            {/* Home Route */}
            <li className="nav-item">
              <NavLink
                to="/"
                end
                className={({ isActive }) =>
                  `custom-nav-link ${isActive ? 'active' : ''}`
                }
                onClick={closeNav}
              >
                <i className="bi bi-house-door-fill"></i>
                <span>Home</span>
              </NavLink>
            </li>

            {/* Team Route */}
            <li className="nav-item">
              <NavLink
                to="/team"
                className={({ isActive }) =>
                  `custom-nav-link ${isActive ? 'active' : ''}`
                }
                onClick={closeNav}
              >
                <i className="bi bi-people-fill"></i>
                <span>Team</span>
              </NavLink>
            </li>

            {/* Contact Route */}
            <li className="nav-item">
              <NavLink
                to="/contact"
                className={({ isActive }) =>
                  `custom-nav-link ${isActive ? 'active' : ''}`
                }
                onClick={closeNav}
              >
                <i className="bi bi-envelope-paper-fill"></i>
                <span>Contact</span>
              </NavLink>
            </li>
          </ul>

          {/* Akses Eksternal: Portal Trisakti */}
          <div className="nav-cta-wrapper ms-lg-3 mt-3 mt-lg-0">
            <a
              href="https://www.trisakti.ac.id"
              target="_blank"
              rel="noreferrer"
              className="btn btn-trisakti-portal btn-sm px-3 py-2 rounded-pill d-inline-flex align-items-center gap-2"
              onClick={closeNav}
            >
              <i className="bi bi-box-arrow-up-right"></i>
              <span>Portal Trisakti</span>
            </a>
          </div>
        </div>
      </div>
    </nav>
  );
}
