// Data dummy untuk Sistem Pengelolaan Parkir Universitas Trisakti

export const initialVehicles = [
  {
    id: "VH-001",
    plate: "B 1998 USA",
    owner: "Dr. Ir. Hendra Gunawan, M.T.",
    role: "Dosen",
    idNumber: "0312047801",
    department: "Teknik Informatika",
    type: "Mobil",
    brand: "Honda CR-V Hitam",
    zone: "Zona Gedung M (VIP/Dosen)",
    status: "Parkir",
    entryTime: "07:15 WIB",
    exitTime: "-"
  },
  {
    id: "VH-002",
    plate: "B 3842 TRK",
    owner: "Nino Sebastiano",
    role: "Mahasiswa",
    idNumber: "065002200001",
    department: "Teknik Informatika",
    type: "Motor",
    brand: "Yamaha NMAX Hitam",
    zone: "Zona Gedung H & L",
    status: "Parkir",
    entryTime: "07:42 WIB",
    exitTime: "-"
  },
  {
    id: "VH-003",
    plate: "B 6521 WKM",
    owner: "Muhammad Rizki",
    role: "Mahasiswa",
    idNumber: "065002200002",
    department: "Teknik Informatika",
    type: "Mobil",
    brand: "Toyota Yaris Putih",
    zone: "Zona FTI / FTSP",
    status: "Parkir",
    entryTime: "08:05 WIB",
    exitTime: "-"
  }
];

export const teamMembers = [
  {
    id: 1,
    name: "Nino Sebastiano",
    initials: "NS",
    role: "Project Lead & Frontend Developer",
    major: "Informatika Universitas Trisakti",
    nim: "065002200001",
    bgColor: "linear-gradient(135deg, #0a3068 0%, #1e3a8a 100%)",
    textColor: "#ffffff",
    bio: "Bertanggung jawab atas arsitektur frontend antarmuka React JS dan integrasi sistem komponen Bootstrap.",
    skills: ["React.js", "Bootstrap 5", "JavaScript", "Frontend Architecture"]
  },
  {
    id: 2,
    name: "Muhammad Rizki",
    initials: "MR",
    role: "Backend Developer & Database Engineer",
    major: "Informatika Universitas Trisakti",
    nim: "065002200002",
    bgColor: "linear-gradient(135deg, #0d9488 0%, #0f766e 100%)",
    textColor: "#ffffff",
    bio: "Fokus pada perancangan logika server, manajemen basis data kendaraan, dan efisiensi query data parkir.",
    skills: ["Node.js", "Express", "Database", "REST API"]
  },
  {
    id: 3,
    name: "Zulfaqih",
    initials: "ZF",
    role: "Fullstack Developer & System Architect",
    major: "Informatika Universitas Trisakti",
    nim: "065002200003",
    bgColor: "linear-gradient(135deg, #d97706 0%, #b45309 100%)",
    textColor: "#ffffff",
    bio: "Menghubungkan antarmuka web dengan service backend dan memastikan keandalan alur sistem secara menyeluruh.",
    skills: ["Fullstack Dev", "System Design", "API Integration", "Git"]
  },
  {
    id: 4,
    name: "Dimas Alip",
    initials: "DA",
    role: "UI/UX Designer & Frontend Engineer",
    major: "Informatika Universitas Trisakti",
    nim: "065002200004",
    bgColor: "linear-gradient(135deg, #4f46e5 0%, #3730a3 100%)",
    textColor: "#ffffff",
    bio: "Merancang wireframe, tata letak antarmuka responsif bertema Trisakti, dan pengalaman pengguna yang intuitif.",
    skills: ["UI/UX Design", "Bootstrap Grid", "CSS Styling", "Prototyping"]
  },
  {
    id: 5,
    name: "Zufar",
    initials: "ZR",
    role: "Quality Assurance & System Analyst",
    major: "Informatika Universitas Trisakti",
    nim: "065002200005",
    bgColor: "linear-gradient(135deg, #0284c7 0%, #0369a1 100%)",
    textColor: "#ffffff",
    bio: "Melakukan pengujian fitur sistem, validasi formulir input, serta dokumentasi spesifikasi kebutuhan aplikasi.",
    skills: ["Quality Assurance", "System Analysis", "Testing", "Documentation"]
  }
];
