import React from 'react';
import { teamMembers } from '../data/parkingData';

export default function Team() {
  return (
    <div className="py-5 bg-light min-vh-100">
      <div className="container py-3">
        {/* Header Section */}
        <div className="text-center mb-5">
          <div className="d-inline-flex align-items-center gap-2 bg-primary bg-opacity-10 text-primary px-3 py-1 rounded-pill small fw-bold mb-3">
            <i className="bi bi-mortarboard-fill text-warning"></i>
            <span>Fakultas Teknologi Industri &bull; FTI Trisakti</span>
          </div>
          <h1 className="fw-bold brand-font text-dark mb-3">
            Tim Pengembang Sistem
          </h1>
          <p className="text-muted mx-auto lead" style={{ maxWidth: '720px', fontSize: '1.05rem' }}>
            Aplikasi ini dikembangkan oleh tim mahasiswa <strong>Informatika Universitas Trisakti</strong> untuk mendukung kemudahan dan kenyamanan civitas kampus.
          </p>
        </div>

        {/* Team Grid Cards using Bootstrap Grid */}
        <div className="row g-4 justify-content-center mb-5">
          {teamMembers.map((member) => (
            <div key={member.id} className="col-lg-4 col-md-6">
              <div className="card team-card h-100 shadow-sm border text-center p-4 bg-white">
                {/* Tampilan Inisial (Tanpa Foto) */}
                <div className="mb-3 d-flex justify-content-center">
                  <div
                    className="rounded-circle d-flex align-items-center justify-content-center shadow-sm"
                    style={{
                      width: '86px',
                      height: '86px',
                      background: member.bgColor,
                      color: member.textColor,
                      fontSize: '1.85rem',
                      fontWeight: '800',
                      letterSpacing: '1px',
                      border: '4px solid #ffffff',
                      boxShadow: '0 8px 20px rgba(0, 0, 0, 0.12)'
                    }}
                  >
                    {member.initials}
                  </div>
                </div>

                {/* Nama Anggota Tim */}
                <h5 className="card-title fw-bold text-dark mb-2 fs-5">
                  {member.name}
                </h5>

                {/* Peran Anggota */}
                <div className="mb-2">
                  <span className="badge bg-warning text-dark fw-bold px-3 py-1 rounded-pill" style={{ fontSize: '0.78rem' }}>
                    {member.role}
                  </span>
                </div>

                {/* Jurusan Universitas Trisakti */}
                <p className="text-primary fw-semibold small mb-1">
                  <i className="bi bi-building me-1"></i> {member.major}
                </p>

                <p className="text-muted font-monospace small mb-3" style={{ fontSize: '0.78rem' }}>
                  NIM: {member.nim}
                </p>

                {/* Bio Singkat */}
                <p className="text-secondary small mb-3 flex-grow-1" style={{ fontSize: '0.88rem', lineHeight: '1.5' }}>
                  {member.bio}
                </p>

                {/* Tags Keahlian */}
                <div className="d-flex flex-wrap justify-content-center gap-1 pt-2 border-top">
                  {member.skills.map((skill, idx) => (
                    <span key={idx} className="badge bg-light text-secondary border small" style={{ fontSize: '0.72rem' }}>
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Info Banner Jurusan Informatika Trisakti */}
        <div className="card border-0 rounded-4 shadow-sm p-4 p-md-5 bg-white text-center">
          <div className="mx-auto" style={{ maxWidth: '680px' }}>
            <div 
              className="rounded-circle d-inline-flex align-items-center justify-content-center bg-primary bg-opacity-10 text-primary p-3 mb-3"
              style={{ width: '64px', height: '64px' }}
            >
              <i className="bi bi-laptop fs-2 text-primary"></i>
            </div>
            <h4 className="fw-bold brand-font text-dark mb-2">
              Jurusan Informatika &bull; FTI Universitas Trisakti
            </h4>
            <p className="text-secondary small mb-0" style={{ lineHeight: '1.7' }}>
              Proyek tugas pengembangan sistem informasi berbasis web responsif untuk pengelolaan parkir terpadu kampus Universitas Trisakti. Dirancang menggunakan React JS dan framework CSS Bootstrap 5.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
