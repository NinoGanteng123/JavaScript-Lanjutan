import React from 'react';
import { Link } from 'react-router-dom';
import ParkingHeroImage from '../components/ParkingHeroImage';

export default function Home() {
  const scrollToFeatures = () => {
    const el = document.getElementById('fitur-utama');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div>
      {/* ========================================================
          1. BANNER UTAMA (HERO SECTION)
         ======================================================== */}
      <section className="hero-section py-5 py-lg-6">
        <div className="container py-3">
          <div className="row align-items-center g-5">
            {/* Left Column: Judul, Deskripsi Singkat, Tombol CTA */}
            <div className="col-lg-6 text-center text-lg-start">
              <div className="hero-badge mb-3">
                <i className="bi bi-patch-check-fill text-warning"></i>
                <span>Smart Campus &bull; Universitas Trisakti</span>
              </div>
              <h1 className="display-4 fw-extrabold text-white mb-3 brand-font lh-sm">
                Sistem Pengelolaan Parkir <span style={{ color: 'var(--usakti-gold)' }}>Universitas Trisakti</span>
              </h1>
              <p className="lead text-white-50 mb-4" style={{ fontSize: '1.15rem', lineHeight: '1.7' }}>
                Platform digital resmi untuk manajemen dan pengelolaan sistem perparkiran modern di lingkungan kampus Universitas Trisakti. Mempermudah pencatatan kendaraan civitas, pemantauan arus lalu lintas, dan penyajian informasi parkir secara efisien.
              </p>
              
              <div className="d-flex flex-wrap gap-3 justify-content-center justify-content-lg-start">
                <button 
                  className="btn btn-trisakti btn-lg px-4 py-3 rounded-pill d-inline-flex align-items-center gap-2"
                  onClick={scrollToFeatures}
                >
                  <i className="bi bi-arrow-down-circle-fill fs-5"></i>
                  <span>Mulai Sekarang</span>
                </button>
                <Link
                  to="/contact"
                  className="btn btn-trisakti-outline btn-lg px-4 py-3 rounded-pill d-inline-flex align-items-center gap-2"
                >
                  <i className="bi bi-headset fs-5"></i>
                  <span>Hubungi Kami</span>
                </Link>
              </div>
            </div>

            {/* Right Column: Gambar / Ilustrasi Parkiran Modern */}
            <div className="col-lg-6">
              <ParkingHeroImage />
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================
          2. BAGIAN FITUR UTAMA (3 CARD BOOTSTRAP)
         ======================================================== */}
      <section id="fitur-utama" className="py-5 bg-white">
        <div className="container py-4">
          <div className="text-center mb-5">
            <span className="badge bg-primary bg-opacity-10 text-primary fw-bold text-uppercase px-3 py-2 rounded-pill mb-2">
              Layanan Utama
            </span>
            <h2 className="fw-bold brand-font text-dark mb-3">
              3 Fitur Utama Sistem Parkir
            </h2>
            <p className="text-muted mx-auto" style={{ maxWidth: '650px' }}>
              Solusi terpadu yang dirancang untuk mendukung operasional pengelolaan parkir di lingkungan Universitas Trisakti.
            </p>
          </div>

          <div className="row g-4">
            {/* Fitur 1: Kelola Data Kendaraan */}
            <div className="col-lg-4 col-md-6">
              <div className="card feature-card h-100 p-4 border shadow-sm">
                <div className="feature-icon-wrapper bg-primary bg-opacity-10 text-primary">
                  <i className="bi bi-card-checklist"></i>
                </div>
                <h4 className="card-title fw-bold text-dark mb-3 fs-5">
                  1. Kelola Data Kendaraan
                </h4>
                <p className="card-text text-secondary mb-3 flex-grow-1" style={{ fontSize: '0.95rem', lineHeight: '1.6' }}>
                  Pencatatan plat nomor, jenis kendaraan, dan identitas pemilik (Mahasiswa/Dosen/Staf).
                </p>
                <ul className="list-unstyled small text-muted border-top pt-3 mb-0 d-flex flex-column gap-2">
                  <li className="d-flex align-items-center gap-2">
                    <i className="bi bi-check2 text-primary fw-bold"></i>
                    <span>Pencatatan nomor plat resmi kendaraan</span>
                  </li>
                  <li className="d-flex align-items-center gap-2">
                    <i className="bi bi-check2 text-primary fw-bold"></i>
                    <span>Klasifikasi kendaraan (Mobil &amp; Sepeda Motor)</span>
                  </li>
                  <li className="d-flex align-items-center gap-2">
                    <i className="bi bi-check2 text-primary fw-bold"></i>
                    <span>Identifikasi civitas (NIM/NIDN pemilik)</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Fitur 2: Aktivitas Real-Time */}
            <div className="col-lg-4 col-md-6">
              <div className="card feature-card h-100 p-4 border shadow-sm">
                <div className="feature-icon-wrapper bg-success bg-opacity-10 text-success">
                  <i className="bi bi-clock-history"></i>
                </div>
                <h4 className="card-title fw-bold text-dark mb-3 fs-5">
                  2. Aktivitas Real-Time
                </h4>
                <p className="card-text text-secondary mb-3 flex-grow-1" style={{ fontSize: '0.95rem', lineHeight: '1.6' }}>
                  Pemantauan arus masuk dan keluar kendaraan secara langsung.
                </p>
                <ul className="list-unstyled small text-muted border-top pt-3 mb-0 d-flex flex-column gap-2">
                  <li className="d-flex align-items-center gap-2">
                    <i className="bi bi-check2 text-success fw-bold"></i>
                    <span>Pencatatan otomatis kendaraan masuk (Gate In)</span>
                  </li>
                  <li className="d-flex align-items-center gap-2">
                    <i className="bi bi-check2 text-success fw-bold"></i>
                    <span>Pencatatan otomatis kendaraan keluar (Gate Out)</span>
                  </li>
                  <li className="d-flex align-items-center gap-2">
                    <i className="bi bi-check2 text-success fw-bold"></i>
                    <span>Waktu dan histori akses portal gerbang kampus</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Fitur 3: Pantau Informasi */}
            <div className="col-lg-4 col-md-6 mx-auto">
              <div className="card feature-card h-100 p-4 border shadow-sm">
                <div className="feature-icon-wrapper bg-warning bg-opacity-15 text-warning-emphasis">
                  <i className="bi bi-bar-chart-line-fill text-warning"></i>
                </div>
                <h4 className="card-title fw-bold text-dark mb-3 fs-5">
                  3. Pantau Informasi
                </h4>
                <p className="card-text text-secondary mb-3 flex-grow-1" style={{ fontSize: '0.95rem', lineHeight: '1.6' }}>
                  Dashboard statistik ketersediaan slot parkir dan laporan harian.
                </p>
                <ul className="list-unstyled small text-muted border-top pt-3 mb-0 d-flex flex-column gap-2">
                  <li className="d-flex align-items-center gap-2">
                    <i className="bi bi-check2 text-warning fw-bold"></i>
                    <span>Informasi rekapitulasi data area parkir</span>
                  </li>
                  <li className="d-flex align-items-center gap-2">
                    <i className="bi bi-check2 text-warning fw-bold"></i>
                    <span>Statistik zonasi parkir Gedung M, H &amp; L, Basement</span>
                  </li>
                  <li className="d-flex align-items-center gap-2">
                    <i className="bi bi-check2 text-warning fw-bold"></i>
                    <span>Laporan harian lalu lintas kendaraan kampus</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================
          3. INFORMASI SINGKAT TENTANG PARKIR TRISAKTI
         ======================================================== */}
      <section className="py-5 bg-light border-top">
        <div className="container py-3">
          <div className="row align-items-center g-4">
            <div className="col-lg-8">
              <h4 className="fw-bold brand-font text-dark mb-2">
                Fasilitas Parkir Kampus Terpadu
              </h4>
              <p className="text-secondary mb-0" style={{ lineHeight: '1.7' }}>
                Sistem pengelolaan parkir Universitas Trisakti melayani area parkir di berbagai titik strategis Kampus A Grogol, termasuk area Gedung M, Gedung H &amp; L, Basement Rektorat, serta area parkir fakultas untuk mendukung kenyamanan seluruh dosen, mahasiswa, dan staf.
              </p>
            </div>
            <div className="col-lg-4 text-center text-lg-end">
              <span className="badge bg-primary px-3 py-2 fs-6 rounded-pill">
                <i className="bi bi-geo-alt-fill me-1 text-warning"></i> Kampus A Grogol
              </span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
