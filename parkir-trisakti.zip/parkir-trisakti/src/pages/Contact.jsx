import React, { useState } from 'react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: 'Pengajuan Stiker & Registrasi Kendaraan',
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);
  const [ticketId, setTicketId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      setTicketId(`TRK-PK-${Math.floor(100000 + Math.random() * 900000)}`);
    }, 700);
  };

  const handleReset = () => {
    setFormData({
      name: '',
      email: '',
      subject: 'Pengajuan Stiker & Registrasi Kendaraan',
      message: ''
    });
    setSubmitted(false);
  };

  return (
    <div className="py-5 bg-light min-vh-100">
      <div className="container py-3">
        {/* Header Section */}
        <div className="text-center mb-5">
          <div className="d-inline-flex align-items-center gap-2 bg-primary bg-opacity-10 text-primary px-3 py-1 rounded-pill small fw-bold mb-3">
            <i className="bi bi-headset text-warning"></i>
            <span>Layanan Bantuan & Informasi Civitas</span>
          </div>
          <h1 className="fw-bold brand-font text-dark mb-3">
            Hubungi Layanan Parkir Universitas Trisakti
          </h1>
          <p className="text-muted mx-auto lead" style={{ maxWidth: '680px', fontSize: '1.05rem' }}>
            Ada pertanyaan seputar registrasi stiker, kendala akses portal RFID, atau ingin menyampaikan saran perbaikan fasilitas parkir? Tim kami siap membantu Anda.
          </p>
        </div>

        <div className="row g-4 mb-5">
          {/* ===================================================
              FORMULIR KONTAK BOOTSTRAP
             =================================================== */}
          <div className="col-lg-7">
            <div className="card border-0 rounded-4 shadow-sm p-4 p-md-5 bg-white h-100">
              <div className="d-flex align-items-center justify-content-between mb-4 pb-2 border-bottom">
                <div>
                  <h4 className="fw-bold brand-font text-dark mb-1">Kirimkan Pesan Anda</h4>
                  <p className="text-secondary small mb-0">Isi formulir di bawah ini dengan lengkap dan benar.</p>
                </div>
                <span className="badge bg-warning text-dark px-3 py-2 fw-semibold">
                  Respon &lt; 24 Jam
                </span>
              </div>

              {submitted ? (
                <div className="alert alert-success border-0 rounded-4 p-4 shadow-sm my-auto text-center">
                  <div className="bg-success text-white rounded-circle p-3 d-inline-flex align-items-center justify-content-center mb-3" style={{ width: '64px', height: '64px' }}>
                    <i className="bi bi-check-lg fs-2"></i>
                  </div>
                  <h4 className="fw-bold text-success mb-2">Pesan Berhasil Terkirim!</h4>
                  <p className="text-secondary mb-3">
                    Terima kasih, <strong>{formData.name}</strong>. Pesan Anda telah diterima oleh Helpdesk Parkir Universitas Trisakti.
                  </p>
                  <div className="p-3 bg-white rounded-3 border d-inline-block text-start mb-4">
                    <small className="text-muted d-block">Nomor Tiket Bantuan:</small>
                    <span className="fw-bold fs-5 font-monospace text-primary">{ticketId}</span>
                    <small className="text-secondary d-block mt-1">Simpan nomor ini untuk pengecekan status permohonan Anda.</small>
                  </div>
                  <div>
                    <button className="btn btn-navy px-4 rounded-pill" onClick={handleReset}>
                      <i className="bi bi-pencil-square me-2"></i> Kirim Pesan Lainnya
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit}>
                  <div className="row g-3">
                    {/* Input Nama */}
                    <div className="col-md-6">
                      <label className="form-label fw-bold small text-secondary">
                        Nama Lengkap <span className="text-danger">*</span>
                      </label>
                      <div className="input-group">
                        <span className="input-group-text bg-light border-end-0 text-muted">
                          <i className="bi bi-person-fill"></i>
                        </span>
                        <input
                          type="text"
                          className="form-control form-control-custom border-start-0"
                          name="name"
                          value={formData.name}
                          onChange={handleChange}
                          placeholder="Contoh: Muhammad Kevin"
                          required
                        />
                      </div>
                    </div>

                    {/* Input Email */}
                    <div className="col-md-6">
                      <label className="form-label fw-bold small text-secondary">
                        Alamat Email <span className="text-danger">*</span>
                      </label>
                      <div className="input-group">
                        <span className="input-group-text bg-light border-end-0 text-muted">
                          <i className="bi bi-envelope-fill"></i>
                        </span>
                        <input
                          type="email"
                          className="form-control form-control-custom border-start-0"
                          name="email"
                          value={formData.email}
                          onChange={handleChange}
                          placeholder="nama@std.trisakti.ac.id"
                          required
                        />
                      </div>
                      <div className="form-text small" style={{ fontSize: '0.75rem' }}>Gunakan email kampus jika Anda civitas Trisakti</div>
                    </div>

                    {/* Input Subjek */}
                    <div className="col-12">
                      <label className="form-label fw-bold small text-secondary">
                        Subjek / Topik Pengaduan <span className="text-danger">*</span>
                      </label>
                      <select
                        className="form-select form-control-custom"
                        name="subject"
                        value={formData.subject}
                        onChange={handleChange}
                      >
                        <option value="Pengajuan Stiker & Registrasi Kendaraan">
                          Pengajuan Stiker &amp; Registrasi Kendaraan Civitas
                        </option>
                        <option value="Kendala Portal RFID & Gate Barrier">
                          Kendala Portal RFID &amp; Gate Barrier Tidak Terbuka
                        </option>
                        <option value="Laporan Kehilangan / Kerusakan di Area Parkir">
                          Laporan Kehilangan / Kerusakan di Area Parkir
                        </option>
                        <option value="Permintaan Akses Tamu VIP / Seminar">
                          Permintaan Akses Tamu VIP / Acara Kampus
                        </option>
                        <option value="Kritik, Saran & Pertanyaan Umum">
                          Kritik, Saran &amp; Pertanyaan Umum
                        </option>
                      </select>
                    </div>

                    {/* Input Pesan */}
                    <div className="col-12">
                      <label className="form-label fw-bold small text-secondary">
                        Isi Pesan / Keterangan Lengkap <span className="text-danger">*</span>
                      </label>
                      <textarea
                        className="form-control form-control-custom"
                        rows="5"
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        placeholder="Tuliskan detail pertanyaan atau keluhan Anda (cantumkan NIM/NIDN dan nomor plat jika relevan)..."
                        required
                      ></textarea>
                    </div>

                    {/* Submit Button */}
                    <div className="col-12 pt-2">
                      <button
                        type="submit"
                        className="btn btn-trisakti btn-lg w-100 rounded-pill py-3 d-flex align-items-center justify-content-center gap-2 shadow-sm"
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? (
                          <>
                            <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                            <span>Sedang Mengirim Pesan...</span>
                          </>
                        ) : (
                          <>
                            <i className="bi bi-send-fill"></i>
                            <span>Kirim Pesan Sekarang</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </form>
              )}
            </div>
          </div>

          {/* ===================================================
              INFORMASI KONTAK RESMI UNIVERSITAS TRISAKTI
             =================================================== */}
          <div className="col-lg-5">
            <div className="card contact-info-card h-100 p-4 p-md-5 d-flex flex-column justify-content-between">
              <div>
                <div className="d-flex align-items-center gap-2 mb-3">
                  <div className="rounded-3 bg-white text-primary p-2 d-flex align-items-center justify-content-center" style={{ width: '38px', height: '38px' }}>
                    <i className="bi bi-building-check fs-5" style={{ color: 'var(--usakti-primary)' }}></i>
                  </div>
                  <div>
                    <h5 className="fw-bold mb-0 text-white brand-font">Universitas Trisakti</h5>
                    <small className="text-warning font-monospace" style={{ fontSize: '0.75rem' }}>OFFICIAL CAMPUS CONTACT</small>
                  </div>
                </div>

                <p className="text-white-50 small mb-4" style={{ lineHeight: '1.6' }}>
                  Pusat layanan informasi resmi operasional parkir, posko keamanan terpadu, dan helpdesk sistem Smart Campus Universitas Trisakti.
                </p>

                <div className="d-flex flex-column gap-3 mb-4">
                  {/* Alamat Kampus */}
                  <div className="d-flex align-items-start gap-3">
                    <div className="contact-icon-box">
                      <i className="bi bi-geo-alt-fill"></i>
                    </div>
                    <div>
                      <div className="text-white-50 small">Alamat Kampus Utama:</div>
                      <div className="text-white fw-semibold small">
                        Kampus A Universitas Trisakti, Jl. Kyai Tapa No. 1, Grogol, Jakarta Barat 11440
                      </div>
                    </div>
                  </div>

                  {/* Email Kampus */}
                  <div className="d-flex align-items-start gap-3">
                    <div className="contact-icon-box">
                      <i className="bi bi-envelope-at-fill"></i>
                    </div>
                    <div>
                      <div className="text-white-50 small">Email Resmi:</div>
                      <div className="text-white fw-semibold small">
                        humas@trisakti.ac.id
                      </div>
                      <div className="text-warning small" style={{ fontSize: '0.78rem' }}>
                        parkir.support@trisakti.ac.id
                      </div>
                    </div>
                  </div>

                  {/* Nomor Telepon */}
                  <div className="d-flex align-items-start gap-3">
                    <div className="contact-icon-box">
                      <i className="bi bi-telephone-fill"></i>
                    </div>
                    <div>
                      <div className="text-white-50 small">Nomor Telepon &amp; Ext:</div>
                      <div className="text-white fw-semibold small">
                        (021) 5663232 Ext. 8114 / 8115
                      </div>
                      <div className="text-white-50 small">
                        Hotline WhatsApp: +62 812-9988-7766
                      </div>
                    </div>
                  </div>

                  {/* Jam Operasional */}
                  <div className="d-flex align-items-start gap-3">
                    <div className="contact-icon-box">
                      <i className="bi bi-clock-fill"></i>
                    </div>
                    <div>
                      <div className="text-white-50 small">Jam Operasional Gerbang &amp; Posko:</div>
                      <div className="text-white fw-semibold small">
                        Gerbang Masuk / Keluar: 24 Jam Non-Stop
                      </div>
                      <div className="text-warning small" style={{ fontSize: '0.78rem' }}>
                        Pelayanan Stiker: Senin - Jumat (08.00 - 16.00 WIB)
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Pos Keamanan Card */}
              <div className="p-3 rounded-3 bg-white bg-opacity-10 border border-light border-opacity-10">
                <div className="d-flex align-items-center gap-2 mb-1">
                  <i className="bi bi-shield-shaded text-warning"></i>
                  <span className="fw-bold small text-white">Posko Keamanan Terpadu (Kamneg)</span>
                </div>
                <small className="text-white-50 d-block" style={{ fontSize: '0.78rem' }}>
                  Petugas patroli dan pemantauan CCTV siaga 24 jam di seluruh area Gedung M, Gedung H, dan Basement.
                </small>
              </div>
            </div>
          </div>
        </div>

        {/* ===================================================
            PETA / LOKASI KAMPUS A UNIVERSITAS TRISAKTI
           =================================================== */}
        <div className="card border-0 rounded-4 shadow-sm overflow-hidden bg-white mb-4">
          <div className="card-header bg-white py-3 px-4 border-bottom d-flex align-items-center justify-content-between">
            <div className="d-flex align-items-center gap-2">
              <i className="bi bi-map-fill text-primary fs-5"></i>
              <h5 className="fw-bold brand-font text-dark mb-0">
                Peta Lokasi Kampus A Universitas Trisakti (Grogol)
              </h5>
            </div>
            <a 
              href="https://maps.google.com/?q=Universitas+Trisakti+Grogol" 
              target="_blank" 
              rel="noreferrer"
              className="btn btn-outline-primary btn-sm rounded-pill px-3"
            >
              <i className="bi bi-box-arrow-up-right me-1"></i> Buka di Google Maps
            </a>
          </div>
          <div className="card-body p-0">
            <div style={{ width: '100%', height: '400px', backgroundColor: '#e2e8f0' }}>
              <iframe
                title="Peta Kampus A Universitas Trisakti"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.720815127022!2d106.78783427499003!3d-6.168123993819176!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f65d0a0b6335%3A0xe9c8bc84ec12d9b6!2sUniversitas%20Trisakti!5e0!3m2!1sid!2sid!4v1710000000000!5m2!1sid!2sid"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
          </div>
          <div className="card-footer bg-light py-3 px-4 d-flex flex-wrap align-items-center justify-content-between gap-2">
            <div className="small text-secondary">
              <i className="bi bi-geo-alt me-1 text-danger"></i>
              Akses Gerbang Utama: Jl. Kyai Tapa &bull; Akses Gerbang Belakang: Jl. Letjen S. Parman
            </div>
            <div className="small">
              <span className="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-2 py-1">
                Lokasi Terverifikasi
              </span>
            </div>
          </div>
        </div>

        {/* Pertanyaan Umum / FAQ Accordion */}
        <div className="card border-0 rounded-4 shadow-sm p-4 bg-white">
          <h5 className="fw-bold brand-font text-dark mb-3 d-flex align-items-center gap-2">
            <i className="bi bi-question-circle-fill text-warning"></i>
            <span>Pertanyaan yang Sering Diajukan (FAQ Parkir Civitas)</span>
          </h5>

          <div className="accordion accordion-flush" id="faqParkingAccordion">
            <div className="accordion-item border-bottom">
              <h2 className="accordion-header" id="faq-heading-1">
                <button 
                  className="accordion-button collapsed fw-semibold text-dark shadow-none" 
                  type="button" 
                  data-bs-toggle="collapse" 
                  data-bs-target="#faq-collapse-1" 
                  aria-expanded="false" 
                  aria-controls="faq-collapse-1"
                >
                  Bagaimana cara mendaftarkan kartu KTM sebagai akses RFID gerbang parkir?
                </button>
              </h2>
              <div id="faq-collapse-1" className="accordion-collapse collapse" aria-labelledby="faq-heading-1" data-bs-parent="#faqParkingAccordion">
                <div className="accordion-body text-secondary small">
                  Mahasiswa aktif cukup membawa KTM resmi dan fotokopi STNK kendaraan ke Biro Administrasi Umum di Gedung M Lantai 1 untuk proses aktivasi chip RFID atau melakukan pendaftaran melalui fitur "Daftarkan Kendaraan" pada sistem web ini.
                </div>
              </div>
            </div>

            <div className="accordion-item border-bottom">
              <h2 className="accordion-header" id="faq-heading-2">
                <button 
                  className="accordion-button collapsed fw-semibold text-dark shadow-none" 
                  type="button" 
                  data-bs-toggle="collapse" 
                  data-bs-target="#faq-collapse-2" 
                  aria-expanded="false" 
                  aria-controls="faq-collapse-2"
                >
                  Apakah ada tarif parkir untuk mahasiswa dan dosen Universitas Trisakti?
                </button>
              </h2>
              <div id="faq-collapse-2" className="accordion-collapse collapse" aria-labelledby="faq-heading-2" data-bs-parent="#faqParkingAccordion">
                <div className="accordion-body text-secondary small">
                  Seluruh civitas akademika (Mahasiswa, Dosen, dan Karyawan) yang telah memiliki stiker parkir dan KTM/RFID terdaftar berhak menikmati fasilitas parkir kampus secara gratis tanpa biaya harian.
                </div>
              </div>
            </div>

            <div className="accordion-item">
              <h2 className="accordion-header" id="faq-heading-3">
                <button 
                  className="accordion-button collapsed fw-semibold text-dark shadow-none" 
                  type="button" 
                  data-bs-toggle="collapse" 
                  data-bs-target="#faq-collapse-3" 
                  aria-expanded="false" 
                  aria-controls="faq-collapse-3"
                >
                  Apa yang harus dilakukan jika tiket parkir atau kartu akses hilang?
                </button>
              </h2>
              <div id="faq-collapse-3" className="accordion-collapse collapse" aria-labelledby="faq-heading-3" data-bs-parent="#faqParkingAccordion">
                <div className="accordion-body text-secondary small">
                  Segera hubungi Posko Keamanan di Gerbang Utama dengan menunjukkan STNK asli kendaraan dan identitas pengenal diri (KTM / KTP / SIM) untuk verifikasi kepemilikan dan pembukaan gate secara manual oleh petugas keamanan.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
