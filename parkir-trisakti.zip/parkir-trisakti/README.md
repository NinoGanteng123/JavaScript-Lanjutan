# Sistem Pengelolaan Parkir Universitas Trisakti

Aplikasi web modern berbasis **React JS** dan **Bootstrap 5** untuk sistem informasi dan manajemen pengelolaan parkir di lingkungan **Universitas Trisakti Jakarta**.

---

## 🌟 Halaman dan Komponen

### 1. Halaman Home
- **Banner Utama (Hero Section)**:
  - Judul: *"Sistem Pengelolaan Parkir Universitas Trisakti"*
  - Deskripsi singkat mengenai sistem parkir kampus.
  - Tombol Call to Action: *"Mulai Sekarang"*.
  - Gambar/Ilustrasi area parkir modern kampus Universitas Trisakti yang bersih dan rapi.
- **Bagian Fitur Utama (3 Card Bootstrap)**:
  1. **Kelola Data Kendaraan**: Pencatatan plat nomor, jenis kendaraan, dan identitas pemilik (Mahasiswa/Dosen/Staf).
  2. **Aktivitas Real-Time**: Pemantauan arus masuk dan keluar kendaraan secara langsung.
  3. **Pantau Informasi**: Dashboard statistik ketersediaan slot parkir dan laporan harian.

### 2. Halaman Team
- Template Card & Grid responsif Bootstrap menampilkan tim pengembang:
  - Foto profil avatar
  - Nama pengembang
  - Peran (Frontend Developer, Backend Developer, IoT Specialist, UI/UX Designer)
  - Jurusan: **Informatika Universitas Trisakti**

### 3. Halaman Contact
- **Formulir Kontak Bootstrap**:
  - Kolom Nama, Email, Subjek, dan Pesan dengan validasi input.
- **Informasi Kontak Resmi Universitas Trisakti**:
  - Alamat Kampus: Kampus A Universitas Trisakti, Jl. Kyai Tapa No. 1, Grogol, Jakarta Barat 11440.
  - Email: `humas@trisakti.ac.id` & `parkir.support@trisakti.ac.id`.
  - Nomor Telepon: `(021) 5663232 Ext. 8114 / 8115`.
  - Peta/Lokasi: Embed Google Maps interaktif Kampus A Trisakti Grogol.

---

## 🚀 Cara Menjalankan

```bash
npm install   # jika belum install dependencies
npm run dev
```

Buka di browser: `http://localhost:5173`
